var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var userManager = require('./userManager');

function log(msg, obj) {
    var date = new Date();
    console.log("=================================================================");
    console.log(date.getFullYear() + "/" + (date.getMonth() + 1) + "/" + date.getDate(), date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds());
    console.log(msg + ": ", obj);
}

/*app.get('/', function (req, res) {
 res.sendfile('C:/Users/BIT/node1/index.html');
 });*/

io.on('connection', function (socket) {

    socket.on("init", function (info) {
        log("init", info);
        socket.info = info;
        userManager.addUser(info, socket);
    });

    socket.on('seatReady', function () {
        userManager.findUsersByDomain(socket.info.domain, function (users) {
            var arr = [];
            for (var i in users) {
                arr.push(i);
            }
            log("onlineUser", arr);
            for (var i in users) {
                users[i].emit("onlineUser", arr);
            }
        });
    });

    socket.on('understanding', function (data) {
        log("understanding", data);
        userManager.findUsersByDomain(socket.info.domain, function (users) {
            for (var i in users) {
                users[i].emit("understanding", data);
            }
        });
    });

    socket.on("seatScore", function (data) {
        log("seatScore", data);
        userManager.findUsersByDomain(socket.info.domain, function (users) {
            for (var i in users) {
                users[i].emit("seatScore", data);
            }
        });
    });

    socket.on("seatQuestion", function(data){
        log("seatQuestion", data);
        userManager.findUsersByDomain(socket.info.domain, function (users) {
            for (var i in users) {
                users[i].emit("seatQuestion", data);
            }
        });
    });

    socket.on('disconnect', function () {
        try {
            var info = socket.info;
            log("disconnect", info);
            userManager.delUser(info);
            userManager.findUsersByDomain(info.domain, function (users) {
                for (var i in users) {
                    users[i].emit("offlineUser", info.userId);
                }
                socket.disconnect();
            });
        } catch (e) {
            console.log(e);
        }
    });

});

http.listen(3000, function () {
    console.log('listening on *:3000');
});
