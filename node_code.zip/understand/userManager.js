module.exports = (function () {
    var academy = {};

    function addUser(info, socket) {
        if(!academy[info.domain])
            academy[info.domain] = {};
        academy[info.domain][info.userId] = socket;
    }

    function delUser(info){
        delete academy[info.domain][info.userId];
    }

    function findUserById(domain, id, callback){
        callback(academy[domain][id]);
    }

    function findUsersByDomain(domain, callback){
        callback(academy[domain]);
    }

    return {addUser: addUser, findUsersByDomain: findUsersByDomain, findUserById: findUserById, delUser: delUser};
})();